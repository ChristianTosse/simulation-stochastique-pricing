# ============================================================
# SCRIPT PRINCIPAL : EXECUTE TOUTES LES SIMULATIONS
# ============================================================
setwd("C:/Users/Christian TOSSE/Desktop/Master 2/ChristProjets/EstimationStochas/CODES R")


cat("========================================\n")
cat("PROJET DE SIMULATION STOCHASTIQUE\n")
cat("Pricing d'options par methodes Monte Carlo\n")


# 1. SIMULATIONS BROWNIENNES
source("simulation_brownien.R")


# 2. DISCRETISATION DES EDS
source("discretisation_EDS.R")

# 3. PRICING MONTE CARLO
source("pricing_mc.R")


# 4. GENERATION DE TOUTES LES FIGURES
source("visualisation.R")
