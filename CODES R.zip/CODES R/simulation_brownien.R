# ============================================================
# SIMULATION DE MOUVEMENTS BROWNIENS STANDARDS ET PONTS
# ============================================================

# Chargement des bibliothèques nécessaires
library(ggplot2)
library(tidyr)
library(dplyr)

# ------------------------------------------------------------
# 1. SIMULATION DU MOUVEMENT BROWNIEN STANDARD
# ------------------------------------------------------------

simuler_brownien <- function(T = 1, N = 1000, M = 10, seed = 123) {
  # T : temps final
  # N : nombre de pas de temps
  # M : nombre de trajectoires
  
  set.seed(seed)
  
  dt <- T / N
  temps <- seq(0, T, length.out = N + 1)
  
  # Simulation des incréments gaussiens
  increments <- matrix(rnorm(M * N, mean = 0, sd = sqrt(dt)), nrow = N, ncol = M)
  
  # Construction des trajectoires par somme cumulée
  trajectoires <- apply(increments, 2, cumsum)
  trajectoires <- rbind(rep(0, M), trajectoires)  # Ajout de W0 = 0
  
  # Formatage pour ggplot
  resultat <- as.data.frame(trajectoires)
  colnames(resultat) <- paste0("Traj", 1:M)
  resultat$temps <- temps
  
  return(resultat)
}

# ------------------------------------------------------------
# 2. SIMULATION DU PONT BROWNIEN
# ------------------------------------------------------------

simuler_pont_brownien <- function(T = 1, N = 1000, a = 0, b = 0, M = 10, seed = 456) {
  # a : valeur en t=0
  # b : valeur en t=T
  
  set.seed(seed)
  
  dt <- T / N
  temps <- seq(0, T, length.out = N + 1)
  
  # Simulation d'un brownien standard
  increments <- matrix(rnorm(M * N, mean = 0, sd = sqrt(dt)), nrow = N, ncol = M)
  W <- apply(increments, 2, cumsum)
  W <- rbind(rep(0, M), W)
  
  # Transformation en pont brownien
  pont <- matrix(NA, nrow = N + 1, ncol = M)
  for(i in 1:(N+1)) {
    t <- temps[i]
    pont[i,] <- a + (t/T)*(b - a) + (W[i,] - (t/T)*W[N+1,])
  }
  
  # Formatage
  resultat <- as.data.frame(pont)
  colnames(resultat) <- paste0("Traj", 1:M)
  resultat$temps <- temps
  
  return(resultat)
}

# ------------------------------------------------------------
# 3. VISUALISATION DES TRAJECTOIRES
# ------------------------------------------------------------

plot_trajectoires_brownien <- function(df, titre = "Mouvement brownien standard") {
  df_long <- pivot_longer(df, cols = -temps, names_to = "trajectoire", values_to = "valeur")
  
  p <- ggplot(df_long, aes(x = temps, y = valeur, color = trajectoire)) +
    geom_line() +
    theme_minimal() +
    labs(title = titre,
         x = "Temps", y = "W(t)") +
    theme(legend.position = "none") +
    scale_color_viridis_d()
  
  return(p)
}

plot_trajectoires_pont <- function(df, titre = "Pont brownien") {
  df_long <- pivot_longer(df, cols = -temps, names_to = "trajectoire", values_to = "valeur")
  
  p <- ggplot(df_long, aes(x = temps, y = valeur, color = trajectoire)) +
    geom_line() +
    theme_minimal() +
    labs(title = titre,
         x = "Temps", y = "B(t)") +
    theme(legend.position = "none") +
    scale_color_viridis_d()
  
  return(p)
}

# ------------------------------------------------------------
# 4. EXEMPLE D'UTILISATION
# ------------------------------------------------------------

# Simulation de 10 trajectoires browniennes
set.seed(123)
browniens <- simuler_brownien(T = 2, N = 1000, M = 10)
p1 <- plot_trajectoires_brownien(browniens, "10 mouvements browniens standards")
print(p1)
# ggsave("figures/brownien_trajectoires.png", p1, width = 8, height = 5, dpi = 300)

# Simulation de 10 ponts browniens
ponts <- simuler_pont_brownien(T = 1, N = 1000, a = 0, b = 0, M = 10)
p2 <- plot_trajectoires_pont(ponts, "10 ponts browniens")
print(p2)
# ggsave("figures/pont_brownien.png", p2, width = 8, height = 5, dpi = 300)
