# ============================================================
# FONCTIONS DE VISUALISATION (REGROUPEMENT)
# ============================================================

# Ce fichier regroupe toutes les fonctions de visualisation
# déjà incluses dans les fichiers précédents :
# - plot_trajectoires_brownien()
# - plot_trajectoires_pont()
# - comparer_methodes()
# - plot_erreur_discretisation()
# - plot_distribution_ST()
# - plot_convergence()

# Pour exécuter toutes les visualisations du projet :
setwd("C:/Users/Christian TOSSE/Desktop/Master 2/ChristProjets/EstimationStochas/CODES R")

source("simulation_brownien.R")
source("discretisation_EDS.R")
source("pricing_mc.R")

# 1. Brownien et pont
browniens <- simuler_brownien(T = 2, N = 1000, M = 10)
p1 <- plot_trajectoires_brownien(browniens)
ggsave("figures/brownien_trajectoires.png", p1, width = 8, height = 5, dpi = 300)

ponts <- simuler_pont_brownien(T = 1, N = 1000, M = 10)
p2 <- plot_trajectoires_pont(ponts)
ggsave("figures/pont_brownien.png", p2, width = 8, height = 5, dpi = 300)

# 2. Comparaison Euler-Milstein
theta <- 2; mu <- 0.05; sigma <- 0.3; X0 <- 0.04; T <- 2; N <- 500
p3 <- comparer_methodes(X0, theta, mu, sigma, T, N, M = 5)
ggsave("figures/comparaison_euler_milstein.png", p3, width = 10, height = 6, dpi = 300)

# 3. Erreur de discrétisation
df_err <- analyse_erreur_discretisation(X0, theta, mu, sigma, T, N, M = 10000)
p4 <- plot_erreur_discretisation(df_err)
ggsave("figures/erreur_euler_milstein.png", p4, width = 8, height = 5, dpi = 300)

# 4. Distribution des prix
S0 <- 100; K <- 105; T <- 1; r <- 0.03; sigma <- 0.25
call_mc <- prix_call_mc(S0, K, T, r, sigma, M = 100000)
p5 <- plot_distribution_ST(call_mc$ST, K)
ggsave("figures/distribution_ST.png", p5, width = 8, height = 5, dpi = 300)

# 5. Convergence
M_values <- c(100, 500, 1000, 5000, 10000, 25000, 50000, 75000, 100000)
call_bs <- black_scholes_call(S0, K, T, r, sigma)
df_conv <- analyse_convergence(S0, K, T, r, sigma, M_values)
p6 <- plot_convergence(df_conv, call_bs)
ggsave("figures/convergence_mc.png", p6, width = 8, height = 5, dpi = 300)

cat("Toutes les figures ont ete generees dans le dossier 'figures/'\n")
