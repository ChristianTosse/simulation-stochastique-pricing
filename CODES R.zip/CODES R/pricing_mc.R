# ============================================================
# PRICING D'OPTIONS PAR METHODE MONTE CARLO
# MODELE DE BLACK-SCHOLES
# ============================================================

# ------------------------------------------------------------
# 1. SIMULATION DU MOUVEMENT BROWNIEN GEOMETRIQUE
# ------------------------------------------------------------

simuler_GBM <- function(S0 = 100, mu = 0.05, sigma = 0.2, T = 1, N = 252, M = 1000, seed = 321) {
  # S0 : prix initial
  # mu : drift (rendement espéré)
  # sigma : volatilité
  # T : maturité (en années)
  # N : nombre de pas (252 = jours ouvrés)
  # M : nombre de simulations
  
  set.seed(seed)
  
  dt <- T / N
  temps <- seq(0, T, length.out = N + 1)
  
  # Simulation des incréments
  increments <- matrix(rnorm(M * N, mean = (mu - sigma^2/2) * dt, sd = sigma * sqrt(dt)), 
                       nrow = N, ncol = M)
  
  # Construction des trajectoires
  log_returns <- apply(increments, 2, cumsum)
  log_returns <- rbind(rep(0, M), log_returns)
  
  # Prix
  prix <- S0 * exp(log_returns)
  
  # Formatage
  resultat <- as.data.frame(prix)
  colnames(resultat) <- paste0("Sim", 1:M)
  resultat$temps <- temps
  
  return(list(prix = resultat, temps = temps))
}

# ------------------------------------------------------------
# 2. PRICING MONTE CARLO D'UN CALL EUROPEEN
# ------------------------------------------------------------

prix_call_mc <- function(S0, K, T, r, sigma, M = 100000, seed = 456) {
  
  set.seed(seed)
  
  # Simulation des prix terminaux sous probabilité risque-neutre
  Z <- rnorm(M)
  ST <- S0 * exp((r - sigma^2/2) * T + sigma * sqrt(T) * Z)
  
  # Payoff
  payoff <- pmax(ST - K, 0)
  
  # Prix actualisé
  prix <- exp(-r * T) * mean(payoff)
  
  # Intervalle de confiance
  se <- exp(-r * T) * sd(payoff) / sqrt(M)
  ic_bas <- prix - 1.96 * se
  ic_haut <- prix + 1.96 * se
  
  return(list(prix = prix, ic = c(ic_bas, ic_haut), ST = ST))
}

# ------------------------------------------------------------
# 3. PRICING MONTE CARLO D'UN PUT EUROPEEN
# ------------------------------------------------------------

prix_put_mc <- function(S0, K, T, r, sigma, M = 100000, seed = 456) {
  
  set.seed(seed)
  
  # Simulation des prix terminaux sous probabilité risque-neutre
  Z <- rnorm(M)
  ST <- S0 * exp((r - sigma^2/2) * T + sigma * sqrt(T) * Z)
  
  # Payoff
  payoff <- pmax(K - ST, 0)
  
  # Prix actualisé
  prix <- exp(-r * T) * mean(payoff)
  
  # Intervalle de confiance
  se <- exp(-r * T) * sd(payoff) / sqrt(M)
  ic_bas <- prix - 1.96 * se
  ic_haut <- prix + 1.96 * se
  
  return(list(prix = prix, ic = c(ic_bas, ic_haut), ST = ST))
}

# ------------------------------------------------------------
# 4. FORMULE FERMEE DE BLACK-SCHOLES
# ------------------------------------------------------------

black_scholes_call <- function(S0, K, T, r, sigma) {
  d1 <- (log(S0 / K) + (r + sigma^2/2) * T) / (sigma * sqrt(T))
  d2 <- d1 - sigma * sqrt(T)
  prix <- S0 * pnorm(d1) - K * exp(-r * T) * pnorm(d2)
  return(prix)
}

black_scholes_put <- function(S0, K, T, r, sigma) {
  d1 <- (log(S0 / K) + (r + sigma^2/2) * T) / (sigma * sqrt(T))
  d2 <- d1 - sigma * sqrt(T)
  prix <- K * exp(-r * T) * pnorm(-d2) - S0 * pnorm(-d1)
  return(prix)
}

# ------------------------------------------------------------
# 5. ANALYSE DE LA CONVERGENCE
# ------------------------------------------------------------

analyse_convergence <- function(S0, K, T, r, sigma, 
                                M_values = c(100, 500, 1000, 5000, 10000, 
                                             25000, 50000, 75000, 100000, 
                                             250000, 500000),
                                seed = 456) {
  
  set.seed(seed)
  prix_bs <- black_scholes_call(S0, K, T, r, sigma)
  
  resultats <- data.frame(
    M = M_values,
    Prix_MC = NA,
    Borne_inf = NA,
    Borne_sup = NA,
    Erreur_abs = NA,
    Erreur_rel = NA
  )
  
  for(i in 1:length(M_values)) {
    M <- M_values[i]
    
    # Simulation
    Z <- rnorm(M)
    ST <- S0 * exp((r - sigma^2/2) * T + sigma * sqrt(T) * Z)
    payoff <- pmax(ST - K, 0)
    prix <- exp(-r * T) * mean(payoff)
    
    # Intervalle de confiance
    se <- exp(-r * T) * sd(payoff) / sqrt(M)
    
    resultats$Prix_MC[i] <- prix
    resultats$Borne_inf[i] <- prix - 1.96 * se
    resultats$Borne_sup[i] <- prix + 1.96 * se
    resultats$Erreur_abs[i] <- abs(prix - prix_bs)
    resultats$Erreur_rel[i] <- 100 * abs(prix - prix_bs) / prix_bs
  }
  
  return(list(resultats = resultats, prix_bs = prix_bs))
}

# ------------------------------------------------------------
# 6. VISUALISATIONS
# ------------------------------------------------------------

plot_distribution_ST <- function(ST, K, prix_bs = NULL) {
  
  df <- data.frame(ST = ST)
  prix_mc <- exp(-r * T) * mean(pmax(ST - K, 0))
  
  p <- ggplot(df, aes(x = ST)) +
    geom_histogram(aes(y = after_stat(density)), bins = 100, 
                   fill = "skyblue", color = "black", alpha = 0.7) +
    geom_density(color = "red", linewidth = 1) +
    geom_vline(xintercept = K, color = "darkgreen", linetype = "dashed", linewidth = 1) +
    annotate("text", x = K + 15, y = 0.02, 
             label = paste("Strike =", K), color = "darkgreen") +
    theme_minimal() +
    labs(title = "Distribution des prix de l'actif a maturite",
         subtitle = paste("M =", length(ST), "simulations"),
         x = "Prix a maturite S(T)", y = "Densite") +
    xlim(0, 250)
  
  return(p)
}

plot_convergence <- function(df_conv, prix_bs) {
  
  p <- ggplot(df_conv$resultats, aes(x = M, y = Prix_MC)) +
    geom_ribbon(aes(ymin = Borne_inf, ymax = Borne_sup), alpha = 0.2, fill = "gray") +
    geom_line(color = "blue", size = 1) +
    geom_point(color = "blue", size = 2) +
    geom_hline(yintercept = prix_bs, color = "red", linetype = "dashed", size = 1) +
    scale_x_log10() +
    theme_minimal() +
    labs(title = "Convergence de l'estimateur Monte Carlo",
         x = "Nombre de simulations M (echelle log)",
         y = "Prix estime") +
    theme(plot.title = element_text(hjust = 0.5))
  
  return(p)
}

# ------------------------------------------------------------
# 7. EXEMPLE D'UTILISATION
# ------------------------------------------------------------

# Paramètres
S0 <- 100
K <- 105
T <- 1
r <- 0.03
sigma <- 0.25
M <- 100000

# Pricing call
call_mc <- prix_call_mc(S0, K, T, r, sigma, M)
call_bs <- black_scholes_call(S0, K, T, r, sigma)

# Pricing put
put_mc <- prix_put_mc(S0, K, T, r, sigma, M)
put_bs <- black_scholes_put(S0, K, T, r, sigma)

# Affichage des résultats
cat("=== PRICING D'OPTIONS ===\n")
cat(sprintf("Call MC  = %.3f [%.3f, %.3f]\n", call_mc$prix, call_mc$ic[1], call_mc$ic[2]))
cat(sprintf("Call BS  = %.3f\n", call_bs))
cat(sprintf("Ecart    = %.2f%%\n", 100 * abs(call_mc$prix - call_bs) / call_bs))
cat("\n")
cat(sprintf("Put MC   = %.3f [%.3f, %.3f]\n", put_mc$prix, put_mc$ic[1], put_mc$ic[2]))
cat(sprintf("Put BS   = %.3f\n", put_bs))
cat(sprintf("Ecart    = %.2f%%\n", 100 * abs(put_mc$prix - put_bs) / put_bs))

# Distribution des prix
p_dist <- plot_distribution_ST(call_mc$ST, K)
print(p_dist)
# ggsave("figures/distribution_ST.png", p_dist, width = 8, height = 5, dpi = 300)

# Analyse de convergence
M_values <- c(100, 500, 1000, 5000, 10000, 25000, 50000, 75000, 100000, 250000, 500000)
df_conv <- analyse_convergence(S0, K, T, r, sigma, M_values)
p_conv <- plot_convergence(df_conv, call_bs)
print(p_conv)
# ggsave("figures/convergence_mc.png", p_conv, width = 8, height = 5, dpi = 300)

# Tableau de convergence
print("\n=== ANALYSE DE LA CONVERGENCE ===")
print(df_conv$resultats[, c("M", "Prix_MC", "Erreur_rel")])
