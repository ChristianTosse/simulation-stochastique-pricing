# ============================================================
# SIMULATION DE MOUVEMENTS BROWNIENS STANDARDS
# ============================================================

# Chargement des bibliothèques nécessaires
library(ggplot2)
library(tidyr)
library(dplyr)

# Fonction pour simuler un mouvement brownien
simuler_brownien <- function(T = 1, N = 1000, M = 1, seed = 123) {
  # T : temps final
  # N : nombre de pas de temps
  # M : nombre de trajectoires
  set.seed(seed)
  
  dt <- T / N
  temps <- seq(0, T, length.out = N + 1)
  
  # Simulation des incréments gaussiens
  increments <- matrix(rnorm(M * N, mean = 0, sd = sqrt(dt)), nrow = N, ncol = M)
  
  # Construction des trajectoires par somme cumulée
  trajectoires <- apply(increments, 2, cumsum)
  trajectoires <- rbind(rep(0, M), trajectoires)  # Ajout de W0 = 0
  
  # Formatage pour ggplot
  resultat <- as.data.frame(trajectoires)
  colnames(resultat) <- paste0("Traj", 1:M)
  resultat$temps <- temps
  
  return(resultat)
}

# Simulation de 10 trajectoires
set.seed(123)
browniens <- simuler_brownien(T = 2, N = 1000, M = 10)

# Visualisation
browniens_long <- pivot_longer(browniens, cols = -temps, names_to = "trajectoire", values_to = "valeur")

ggplot(browniens_long, aes(x = temps, y = valeur, color = trajectoire)) +
  geom_line() +
  theme_minimal() +
  labs(title = "Simulation de 10 mouvements browniens standards",
       x = "Temps", y = "W(t)") +
  theme(legend.position = "none") +
  scale_color_viridis_d()







# ============================================================
# SIMULATION DE PONTS BROWNIENS
# ============================================================

simuler_pont_brownien <- function(T = 1, N = 1000, a = 0, b = 0, M = 1, seed = 456) {
  # a : valeur en t=0
  # b : valeur en t=T
  set.seed(seed)
  
  dt <- T / N
  temps <- seq(0, T, length.out = N + 1)
  
  # Simulation d'un brownien standard
  increments <- matrix(rnorm(M * N, mean = 0, sd = sqrt(dt)), nrow = N, ncol = M)
  W <- apply(increments, 2, cumsum)
  W <- rbind(rep(0, M), W)
  
  # Transformation en pont brownien
  pont <- matrix(NA, nrow = N + 1, ncol = M)
  for(i in 1:(N+1)) {
    t <- temps[i]
    pont[i,] <- a + (t/T)*(b - a) + (W[i,] - (t/T)*W[N+1,])
  }
  
  # Formatage
  resultat <- as.data.frame(pont)
  colnames(resultat) <- paste0("Traj", 1:M)
  resultat$temps <- temps
  
  return(resultat)
}

# Simulation de ponts browniens (a=0, b=0)
ponts <- simuler_pont_brownien(T = 1, N = 1000, a = 0, b = 0, M = 10)

# Visualisation
ponts_long <- pivot_longer(ponts, cols = -temps, names_to = "trajectoire", values_to = "valeur")

ggplot(ponts_long, aes(x = temps, y = valeur, color = trajectoire)) +
  geom_line() +
  theme_minimal() +
  labs(title = "Simulation de 10 ponts browniens (a=0, b=0)",
       x = "Temps", y = "B(t)") +
  theme(legend.position = "none") +
  scale_color_viridis_d()







# ============================================================
# COMPARAISON DES MÉTHODES EULER-MARUYAMA ET MILSTEIN
# ============================================================

# Exemple : équation de Cox-Ingersoll-Ross (CIR) pour les taux d'intérêt
# dX_t = theta*(mu - X_t)dt + sigma*sqrt(X_t)dW_t

# Paramètres
theta <- 2      # vitesse de retour à la moyenne
mu <- 0.05      # moyenne à long terme
sigma <- 0.3    # volatilité
X0 <- 0.04      # valeur initiale
T <- 1          # horizon temporel
N <- 100        # nombre de pas
dt <- T / N
M <- 5          # nombre de trajectoires

set.seed(789)

# Simulation des incréments browniens
dW <- matrix(rnorm(M * N, mean = 0, sd = sqrt(dt)), nrow = N, ncol = M)

# Initialisation
X_euler <- matrix(NA, nrow = N + 1, ncol = M)
X_milstein <- matrix(NA, nrow = N + 1, ncol = M)
X_euler[1, ] <- X0
X_milstein[1, ] <- X0

# Boucle temporelle
for(i in 1:N) {
  for(j in 1:M) {
    Xt_euler <- X_euler[i, j]
    Xt_milstein <- X_milstein[i, j]
    
    # Drift et diffusion
    drift <- theta * (mu - max(Xt_euler, 0))
    diffusion <- sigma * sqrt(max(Xt_euler, 0))
    
    # Euler-Maruyama
    X_euler[i+1, j] <- Xt_euler + drift * dt + diffusion * dW[i, j]
    
    # Milstein (avec correction pour sqrt)
    if(Xt_milstein > 0) {
      diffusion_m <- sigma * sqrt(Xt_milstein)
      diff_derivee <- sigma / (2 * sqrt(Xt_milstein))
      X_milstein[i+1, j] <- Xt_milstein + theta*(mu - Xt_milstein)*dt + 
        diffusion_m * dW[i, j] + 
        0.5 * diffusion_m * diff_derivee * (dW[i,j]^2 - dt)
    } else {
      X_milstein[i+1, j] <- Xt_milstein + theta*mu*dt  # approximation si Xt proche de 0
    }
  }
}

# Formatage pour visualisation
temps <- seq(0, T, length.out = N + 1)

df_euler <- as.data.frame(X_euler)
colnames(df_euler) <- paste0("Traj", 1:M)
df_euler$temps <- temps
df_euler$methode <- "Euler-Maruyama"

df_milstein <- as.data.frame(X_milstein)
colnames(df_milstein) <- paste0("Traj", 1:M)
df_milstein$temps <- temps
df_milstein$methode <- "Milstein"

# Fusion
df_compare <- rbind(
  pivot_longer(df_euler, cols = -c(temps, methode), names_to = "trajectoire", values_to = "valeur"),
  pivot_longer(df_milstein, cols = -c(temps, methode), names_to = "trajectoire", values_to = "valeur")
)

# Visualisation
ggplot(df_compare, aes(x = temps, y = valeur, color = methode, group = interaction(trajectoire, methode))) +
  geom_line(alpha = 0.7) +
  facet_wrap(~trajectoire, ncol = 2) +
  theme_minimal() +
  labs(title = "Comparaison Euler-Maruyama vs Milstein (modèle CIR)",
       x = "Temps", y = "X(t)") +
  scale_color_manual(values = c("Euler-Maruyama" = "blue", "Milstein" = "red"))







# ============================================================
# MODÈLE DE BLACK-SCHOLES : SIMULATION ET PRICING D'OPTIONS
# ============================================================

# Fonction de simulation du mouvement brownien géométrique
simuler_GBM <- function(S0 = 100, mu = 0.05, sigma = 0.2, T = 1, N = 252, M = 1000, seed = 321) {
  # S0 : prix initial
  # mu : drift (rendement espéré)
  # sigma : volatilité
  # T : maturité (en années)
  # N : nombre de pas (252 = jours ouvrés)
  # M : nombre de simulations
  
  set.seed(seed)
  
  dt <- T / N
  temps <- seq(0, T, length.out = N + 1)
  
  # Simulation des incréments
  increments <- matrix(rnorm(M * N, mean = (mu - sigma^2/2) * dt, sd = sigma * sqrt(dt)), 
                       nrow = N, ncol = M)
  
  # Construction des trajectoires
  log_returns <- apply(increments, 2, cumsum)
  log_returns <- rbind(rep(0, M), log_returns)
  
  # Prix
  prix <- S0 * exp(log_returns)
  
  # Formatage
  resultat <- as.data.frame(prix)
  colnames(resultat) <- paste0("Sim", 1:M)
  resultat$temps <- temps
  
  return(list(prix = resultat, temps = temps))
}

# Simulation
set.seed(321)
sim_GBM <- simuler_GBM(S0 = 100, mu = 0.05, sigma = 0.3, T = 1, N = 252, M = 1000)

# Visualisation de 20 trajectoires
prix_df <- sim_GBM$prix
prix_sample <- prix_df[, c(1:20, ncol(prix_df))]  # 20 premières + colonne temps

prix_long <- pivot_longer(prix_sample, cols = -temps, names_to = "simulation", values_to = "prix")

ggplot(prix_long, aes(x = temps, y = prix, color = simulation)) +
  geom_line(alpha = 0.7) +
  theme_minimal() +
  labs(title = "Simulation de 20 trajectoires Black-Scholes",
       subtitle = expression(paste(S[0], " = 100, ", mu, " = 0.05, ", sigma, " = 0.3")),
       x = "Temps (années)", y = "Prix de l'actif") +
  theme(legend.position = "none") +
  scale_y_log10()  # échelle log pour mieux voir






# ============================================================
# PRICING D'OPTIONS EUROPÉENNES PAR SIMULATION MONTE CARLO
# ============================================================

# Paramètres
S0 <- 100          # prix spot
K <- 105           # strike
T <- 1             # maturité (1 an)
r <- 0.03          # taux sans risque
sigma <- 0.25      # volatilité
N <- 252           # pas de temps (quotidien)
M <- 100000        # nombre de simulations

set.seed(456)

# Simulation des prix à maturité
dt <- T / N
Z <- rnorm(M, mean = 0, sd = 1)

# Prix terminal sous la probabilité risque-neutre (mu = r)
ST <- S0 * exp((r - sigma^2/2) * T + sigma * sqrt(T) * Z)

# Payoff des options
payoff_call <- pmax(ST - K, 0)
payoff_put <- pmax(K - ST, 0)

# Prix actuariels (actualisation)
prix_call_mc <- exp(-r * T) * mean(payoff_call)
prix_put_mc <- exp(-r * T) * mean(payoff_put)

# Intervalles de confiance
se_call <- exp(-r * T) * sd(payoff_call) / sqrt(M)
se_put <- exp(-r * T) * sd(payoff_put) / sqrt(M)

ic_call <- c(prix_call_mc - 1.96*se_call, prix_call_mc + 1.96*se_call)
ic_put <- c(prix_put_mc - 1.96*se_put, prix_put_mc + 1.96*se_put)

# Formule fermée de Black-Scholes pour comparaison
black_scholes <- function(S0, K, T, r, sigma, type = "call") {
  d1 <- (log(S0/K) + (r + sigma^2/2) * T) / (sigma * sqrt(T))
  d2 <- d1 - sigma * sqrt(T)
  
  if(type == "call") {
    prix <- S0 * pnorm(d1) - K * exp(-r * T) * pnorm(d2)
  } else {
    prix <- K * exp(-r * T) * pnorm(-d2) - S0 * pnorm(-d1)
  }
  return(prix)
}

prix_call_bs <- black_scholes(S0, K, T, r, sigma, "call")
prix_put_bs <- black_scholes(S0, K, T, r, sigma, "put")

# Tableau comparatif
resultats <- data.frame(
  Méthode = c("Monte Carlo", "Black-Scholes", "Différence (%)"),
  Call = c(round(prix_call_mc, 3), round(prix_call_bs, 3), 
           round(100*abs(prix_call_mc - prix_call_bs)/prix_call_bs, 2)),
  Put = c(round(prix_put_mc, 3), round(prix_put_bs, 3),
          round(100*abs(prix_put_mc - prix_put_bs)/prix_put_bs, 2))
)

print("=== PRIX DES OPTIONS ===")
print(resultats)

print(paste("IC Call à 95% : [", round(ic_call[1], 3), ",", round(ic_call[2], 3), "]"))
print(paste("IC Put à 95%  : [", round(ic_put[1], 3), ",", round(ic_put[2], 3), "]"))

# Visualisation de la distribution des prix terminaux
df_ST <- data.frame(ST = ST)

ggplot(df_ST, aes(x = ST)) +
  geom_histogram(aes(y = after_stat(density)), bins = 100, fill = "skyblue", color = "black", alpha = 0.7) +
  geom_density(color = "red", linewidth = 1) +
  geom_vline(xintercept = K, color = "darkgreen", linetype = "dashed", linewidth = 1) +
  annotate("text", x = K + 15, y = 0.02, label = paste("Strike =", K), color = "darkgreen") +
  theme_minimal() +
  labs(title = "Distribution des prix de l'actif à maturité",
       subtitle = paste("M =", M, "simulations"),
       x = "Prix à maturité S(T)", y = "Densité") +
  xlim(0, 250)





