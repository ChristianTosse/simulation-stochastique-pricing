# ============================================================
# DISCRETISATION DES EDS : EULER-MARUYAMA ET MILSTEIN
# MODELE CIR (Cox-Ingersoll-Ross)
# ============================================================

# ------------------------------------------------------------
# 1. METHODE D'EULER-MARUYAMA POUR LE MODELE CIR
# ------------------------------------------------------------

euler_maruyama_CIR <- function(X0, theta, mu, sigma, T, N, M = 1, seed = 789) {
  # X0 : valeur initiale
  # theta : vitesse de retour à la moyenne
  # mu : moyenne long terme
  # sigma : volatilité
  # T : horizon temporel
  # N : nombre de pas
  # M : nombre de trajectoires
  
  set.seed(seed)
  dt <- T / N
  dW <- matrix(rnorm(M * N, mean = 0, sd = sqrt(dt)), nrow = N, ncol = M)
  
  X <- matrix(NA, nrow = N + 1, ncol = M)
  X[1, ] <- X0
  
  for(i in 1:N) {
    for(j in 1:M) {
      Xt <- X[i, j]
      X_pos <- max(Xt, 0)
      drift <- theta * (mu - X_pos)
      diffusion <- sigma * sqrt(X_pos)
      
      X[i + 1, j] <- Xt + drift * dt + diffusion * dW[i, j]
      X[i + 1, j] <- max(X[i + 1, j], 0)  # Garantir la positivité
    }
  }
  
  return(X)
}

# ------------------------------------------------------------
# 2. METHODE DE MILSTEIN POUR LE MODELE CIR
# ------------------------------------------------------------

milstein_CIR <- function(X0, theta, mu, sigma, T, N, M = 1, seed = 789) {
  
  set.seed(seed)
  dt <- T / N
  dW <- matrix(rnorm(M * N, mean = 0, sd = sqrt(dt)), nrow = N, ncol = M)
  
  X <- matrix(NA, nrow = N + 1, ncol = M)
  X[1, ] <- X0
  
  for(i in 1:N) {
    for(j in 1:M) {
      Xt <- X[i, j]
      
      if(Xt > 1e-8) {
        diffusion <- sigma * sqrt(Xt)
        diff_derivee <- sigma / (2 * sqrt(Xt))
        
        X[i + 1, j] <- Xt + theta * (mu - Xt) * dt + 
          diffusion * dW[i, j] + 
          0.5 * diffusion * diff_derivee * (dW[i, j]^2 - dt)
      } else {
        # Approximation si Xt proche de 0
        X[i + 1, j] <- max(0, Xt + theta * mu * dt + 
                             sigma * sqrt(abs(Xt)) * dW[i, j])
      }
      
      X[i + 1, j] <- max(X[i + 1, j], 0)
    }
  }
  
  return(X)
}

# ------------------------------------------------------------
# 3. ANALYSE DE L'ERREUR DE DISCRETISATION
# ------------------------------------------------------------

analyse_erreur_discretisation <- function(X0, theta, mu, sigma, T, N, M = 10000, seed = 789) {
  
  # Simulation avec les deux méthodes
  X_euler <- euler_maruyama_CIR(X0, theta, mu, sigma, T, N, M, seed)
  X_milstein <- milstein_CIR(X0, theta, mu, sigma, T, N, M, seed)
  
  # Calcul de l'écart absolu moyen
  erreur_absolue <- abs(X_milstein - X_euler)
  erreur_moyenne <- rowMeans(erreur_absolue)
  
  # Valeur moyenne du processus
  valeur_moyenne <- rowMeans((X_euler + X_milstein) / 2)
  erreur_relative <- 100 * erreur_moyenne / valeur_moyenne
  
  # Création du data frame
  temps <- seq(0, T, length.out = N + 1)
  df_erreur <- data.frame(
    temps = temps,
    erreur_absolue = erreur_moyenne,
    erreur_relative = erreur_relative
  )
  
  return(df_erreur)
}

# ------------------------------------------------------------
# 4. VISUALISATION DE L'ERREUR
# ------------------------------------------------------------

plot_erreur_discretisation <- function(df_erreur, titre = "Erreur de discretisation") {
  
  p <- ggplot(df_erreur, aes(x = temps, y = erreur_absolue)) +
    geom_line(color = "blue", size = 1) +
    geom_smooth(method = "loess", se = FALSE, color = "red", linetype = "dashed", size = 0.8) +
    theme_minimal() +
    labs(title = titre,
         subtitle = paste("Modele CIR"),
         x = "Temps (annees)", 
         y = "Ecart absolu moyen") +
    theme(plot.title = element_text(hjust = 0.5),
          plot.subtitle = element_text(hjust = 0.5, size = 9))
  
  return(p)
}

# ------------------------------------------------------------
# 5. COMPARAISON VISUELLE DES TRAJECTOIRES
# ------------------------------------------------------------

comparer_methodes <- function(X0, theta, mu, sigma, T, N, M = 5, seed = 789) {
  
  # Simulation des incréments communs
  set.seed(seed)
  dt <- T / N
  dW <- matrix(rnorm(M * N, mean = 0, sd = sqrt(dt)), nrow = N, ncol = M)
  
  # Initialisation
  X_euler <- matrix(NA, nrow = N + 1, ncol = M)
  X_milstein <- matrix(NA, nrow = N + 1, ncol = M)
  X_euler[1, ] <- X0
  X_milstein[1, ] <- X0
  
  for(i in 1:N) {
    for(j in 1:M) {
      Xt_euler <- X_euler[i, j]
      Xt_milstein <- X_milstein[i, j]
      
      # Euler-Maruyama
      X_pos <- max(Xt_euler, 0)
      drift_euler <- theta * (mu - X_pos)
      diffusion_euler <- sigma * sqrt(X_pos)
      X_euler[i + 1, j] <- max(Xt_euler + drift_euler * dt + diffusion_euler * dW[i, j], 0)
      
      # Milstein
      if(Xt_milstein > 1e-8) {
        diffusion_m <- sigma * sqrt(Xt_milstein)
        diff_derivee <- sigma / (2 * sqrt(Xt_milstein))
        X_milstein[i + 1, j] <- Xt_milstein + theta * (mu - Xt_milstein) * dt + 
          diffusion_m * dW[i, j] + 
          0.5 * diffusion_m * diff_derivee * (dW[i, j]^2 - dt)
        X_milstein[i + 1, j] <- max(X_milstein[i + 1, j], 0)
      } else {
        X_milstein[i + 1, j] <- max(0, Xt_milstein + theta * mu * dt + 
                                      sigma * sqrt(abs(Xt_milstein)) * dW[i, j])
      }
    }
  }
  
  # Formatage pour ggplot
  temps <- seq(0, T, length.out = N + 1)
  
  df_euler <- as.data.frame(X_euler)
  colnames(df_euler) <- paste0("Traj", 1:M)
  df_euler$temps <- temps
  df_euler$methode <- "Euler-Maruyama"
  
  df_milstein <- as.data.frame(X_milstein)
  colnames(df_milstein) <- paste0("Traj", 1:M)
  df_milstein$temps <- temps
  df_milstein$methode <- "Milstein"
  
  df_compare <- rbind(
    pivot_longer(df_euler, cols = -c(temps, methode), names_to = "trajectoire", values_to = "valeur"),
    pivot_longer(df_milstein, cols = -c(temps, methode), names_to = "trajectoire", values_to = "valeur")
  )
  
  # Visualisation
  p <- ggplot(df_compare, aes(x = temps, y = valeur, color = methode, 
                              group = interaction(trajectoire, methode))) +
    geom_line(alpha = 0.7) +
    facet_wrap(~trajectoire, ncol = 2) +
    theme_minimal() +
    labs(title = "Comparaison Euler-Maruyama vs Milstein",
         subtitle = paste("Modele CIR avec θ =", theta, ", μ =", mu, ", σ =", sigma),
         x = "Temps", y = "X(t)") +
    scale_color_manual(values = c("Euler-Maruyama" = "blue", "Milstein" = "red"))
  
  return(p)
}

# ------------------------------------------------------------
# 6. EXEMPLE D'UTILISATION
# ------------------------------------------------------------

# Paramètres
theta <- 2      # vitesse de retour à la moyenne
mu <- 0.05      # moyenne à long terme
sigma <- 0.3    # volatilité
X0 <- 0.04      # valeur initiale
T <- 2          # horizon
N <- 500        # nombre de pas
M_comp <- 5     # trajectoires pour comparaison
M_err <- 10000  # trajectoires pour l'erreur

# Comparaison visuelle
p_comp <- comparer_methodes(X0, theta, mu, sigma, T, N, M_comp)
print(p_comp)
# ggsave("figures/comparaison_euler_milstein.png", p_comp, width = 10, height = 6, dpi = 300)

# Analyse de l'erreur
df_err <- analyse_erreur_discretisation(X0, theta, mu, sigma, T, N, M_err)
p_err <- plot_erreur_discretisation(df_err)
print(p_err)
# ggsave("figures/erreur_euler_milstein.png", p_err, width = 8, height = 5, dpi = 300)

# Tableau récapitulatif
horizons <- c(0.5, 1.0, 1.5, 2.0)
indices <- sapply(horizons, function(h) which.min(abs(df_err$temps - h)))
tableau <- data.frame(
  Horizon = horizons,
  Erreur_absolue = round(df_err$erreur_absolue[indices], 5),
  Erreur_relative = round(df_err$erreur_relative[indices], 2)
)
print("=== ERREUR DE DISCRETISATION ===")
print(tableau)

